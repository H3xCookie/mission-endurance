#!/bin/bash

mv $1 ./result/ 


